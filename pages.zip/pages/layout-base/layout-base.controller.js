(function() {
  'use strict';

  angular
    .module('minotaur')
    .controller('LayoutBaseController', LayoutBaseController);

  /** @ngInject */
  function LayoutBaseController() {

  }
})();
