(function() {
  'use strict';

  angular
    .module('minotaur')
    .controller('LayoutBoxedController', LayoutBoxedController);

  /** @ngInject */
  function LayoutBoxedController() {

  }
})();
