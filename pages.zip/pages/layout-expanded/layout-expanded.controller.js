(function() {
  'use strict';

  angular
    .module('minotaur')
    .controller('LayoutExpandedController', LayoutExpandedController);

  /** @ngInject */
  function LayoutExpandedController() {

  }
})();
