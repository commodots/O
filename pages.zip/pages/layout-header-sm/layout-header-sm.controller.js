(function() {
  'use strict';

  angular
    .module('minotaur')
    .controller('LayoutHeaderSmController', LayoutHeaderSmController);

  /** @ngInject */
  function LayoutHeaderSmController() {

  }
})();
