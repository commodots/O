(function() {
  'use strict';

  angular
    .module('minotaur')
    .controller('LayoutHeaderWithContentController', LayoutHeaderWithContentController);

  /** @ngInject */
  function LayoutHeaderWithContentController() {

  }
})();
