(function() {
  'use strict';

  angular
    .module('minotaur')
    .controller('LayoutHzMenuController', LayoutHzMenuController);

  /** @ngInject */
  function LayoutHzMenuController() {

  }
})();
