(function() {
  'use strict';

  angular
    .module('minotaur')
    .controller('LayoutNonFixedHeaderController', LayoutNonFixedHeaderController);

  /** @ngInject */
  function LayoutNonFixedHeaderController() {

  }
})();
