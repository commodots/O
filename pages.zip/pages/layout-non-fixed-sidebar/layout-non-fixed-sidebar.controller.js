(function() {
  'use strict';

  angular
    .module('minotaur')
    .controller('LayoutNonFixedSidebarController', LayoutNonFixedSidebarController);

  /** @ngInject */
  function LayoutNonFixedSidebarController() {

  }
})();
