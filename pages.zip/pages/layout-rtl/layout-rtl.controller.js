(function() {
  'use strict';

  angular
    .module('minotaur')
    .controller('LayoutRtlController', LayoutRtlController);

  /** @ngInject */
  function LayoutRtlController() {

  }
})();
