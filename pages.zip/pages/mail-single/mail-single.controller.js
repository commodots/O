(function() {
  'use strict';

  angular
    .module('minotaur')
    .controller('MailSingleController', MailSingleController);

  /** @ngInject */
  function MailSingleController() {

  }
})();
