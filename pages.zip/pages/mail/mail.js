(function() {
  'use strict';

  angular
    .module('minotaur')
    .controller('MailController', MailController);

  /** @ngInject */
  function MailController() {

  }
})();
