(function() {
  'use strict';

  angular
    .module('minotaur')
    .controller('MainDashboardController', MainDashboardController);

    /** @ngInject */
  function MainDashboardController($scope,$log,Authentication,$timeout,localStorageService,$window,cfpLoadingBar){
    // $scope.$log = $log
    $log.log("okay")
    /**
      * Get user data from localstorage
     */
    var userData = localStorageService.get("userdata");
    var vm = this;
    vm.matchid = userData.matchid;
    vm.name = userData.fullname;
    vm.username  = userData.username
    vm.email =  userData.email;
    vm.mobile = userData.mobile;
    vm.package_from_local = userData.package;

    vm.logout = function(){
      cfpLoadingBar.start();
      Authentication.logout();
      cfpLoadingBar.complete();
    }

    vm.redirectToLogin = function(){
      $window.location.href = '/odi/';
    }
    
    vm.updatePackage =  function(packageid){
        packageid = vm.package;
        var new_package = {
          packageid:packageid
        }
        $log.log(new_package);
        Authentication.updatePackage(new_package)
          .then(function(response){
            $log.log(response.data);
            if(!response.data || response.data == null || response.data == undefined){
              $window.alert("An error occured. Try again later");
            }else{
              if(response.data.code == 0 && response.data.msg == "Token has expired"){
                $window.alert("Your session has expired, you will be logged out");
                localStorageService.remove("token");
                $timeout(vm.redirectToLogin,2000);
              }else if(response.data.code == 1){
                $window.alert("Your package has been successfully updated. Your changes will take effect the next time you log in")
              }
            }

          })
      }
  }

})();