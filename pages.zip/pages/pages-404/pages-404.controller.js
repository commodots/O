(function() {
  'use strict';

  angular
    .module('minotaur')
    .controller('Page404Controller', Page404Controller);

  /** @ngInject */
  function Page404Controller() {

  }

})();
