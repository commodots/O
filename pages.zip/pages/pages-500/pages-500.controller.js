(function() {
  'use strict';

  angular
    .module('minotaur')
    .controller('Page500Controller', Page500Controller);

  /** @ngInject */
  function Page500Controller() {

  }

})();
