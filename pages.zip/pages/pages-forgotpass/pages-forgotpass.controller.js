(function() {
  'use strict';

  angular
    .module('minotaur')
    .controller('ForgotPasswordController', ForgotPasswordController);

  /** @ngInject */
  function ForgotPasswordController($scope,$log,$window,$timeout, $location,Authentication,vcRecaptchaService,cfpLoadingBar) {
    var vm = this;
    vm.success = false;
    vm.failure = false;
    vm.$log = $log;
    vm.submitForm = function(email){
      vm.success = false;
      vm.failure = false;
      cfpLoadingBar.start();
      email = vm.email;
      var formData = {
        email:email
      }
      $log.log(formData);
      Authentication.forgot(formData)
        .then(function(response){
            $log.log(response.data);
            if(response.data.code == 0){
              vm.errormessage = response.data.msg;
              vm.failure = true;
              cfpLoadingBar.complete();
            }else{
              vm.successmessage = response.data.msg;
              vm.success = true;
              cfpLoadingBar.complete();
            }
            
        })
    }
  }

})();
