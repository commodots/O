(function() {
  'use strict';

  angular
    .module('minotaur')
    .controller('LockedController', LockedController);

  /** @ngInject */
  function LockedController() {

  }

})();
