(function() {
  'use strict';

  angular
    .module('minotaur')
    .controller('LoginController', LoginController);

  /** @ngInject */
  function LoginController($scope,$log,$window,$timeout, $location,Authentication,cfpLoadingBar,localStorageService) {
    /**
      * $auth is a service from the satellizer module used for social logins
     */
    var vm = this;  
    vm.failure = false; 
    vm.saveInLocalstorage = function(name,value){
      if(localStorageService.isSupported){
        // $log.log(token);
        return localStorageService.set(name,value);
      }
    }
    vm.redirectToDashboard = function(){
      $window.location.href = $window.location.origin+"/#/app/dashboard";
    } 
    /**
      * Facebook login
     */
    // vm.authenticate = function(provider){
    //   $auth.authenticate(provider)
    //     .then(function(response){
    //       $log.log(response);
    //     })
    //     .catch(function(error){
    //       $log.log(error);
    //     })
    // }

     //end
     /**
        * Normal login
      */
    vm.submitForm = function(email,password){
      /**
         * get the response from the login service
         * Check the response for the token 
         * if available, save it in localStorage using 'localforage'
         * NB -- saving the token in localstorage is done here because nodejs does not have a window object and since localStorage is accessed from 'window' as in 'window.localStorage', we can only deal with localstorage in the browser.
      */
      vm.success = false;
      vm.failure = false;
      vm.failure = false;       
      cfpLoadingBar.start();
      email = vm.email;
      password = vm.password;
      var formData = {
        email : email,
        password: password
      };
      vm.$log = $log;
      $log.log(formData);
      // $log.log(formData);
      Authentication.login(formData)
        .then(function(response){
          // $log.log(response.data);
          // $log.log(response.data.user);
          if(!response.data || response.data == null || response.data == undefined){
            vm.errormessage = "An error occured. Check your internet connection";
            vm.failure = true;
            cfpLoadingBar.complete();
            return;
          }else{
            if(response.data.code == 0){
              vm.errormessage = response.data.message;
              vm.failure = true;
              cfpLoadingBar.complete();
              return
            }
            else{
              vm.saveInLocalstorage("token",response.data.token);
              vm.saveInLocalstorage("userdata",response.data.user);
              $timeout(vm.redirectToDashboard,3000);
              cfpLoadingBar.complete();
              return;
            }
          }
          
        })
    }
  }

})();
