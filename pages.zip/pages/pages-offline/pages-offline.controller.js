(function() {
  'use strict';

  angular
    .module('minotaur')
    .controller('PageOfflineController', PageOfflineController);

  /** @ngInject */
  function PageOfflineController() {

  }

})();
