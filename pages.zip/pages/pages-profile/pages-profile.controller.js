(function() {
  'use strict';

  angular
    .module('minotaur')
    .controller('PagesProfileController', PagesProfileController);

  /** @ngInject */
  function PagesProfileController() {

  }


})();
