(function() {
  'use strict';

  angular
    .module('minotaur')
    .controller('ResetPasswordController', ResetPasswordController);

  /** @ngInject */
  function ResetPasswordController($scope,$log,$window,$timeout, $location,Authentication,$stateParams,cfpLoadingBar) {
    /*
      *$stateParams is used here because the template uses angular-ui-router hence $routeParams will not work
    */
    var vm = this;
    vm.success = false;
    vm.failure = false;
    vm.$log = $log;
    var token = $stateParams.token;
    $log.log(token);

    vm.submitForm = function(password){
      vm.success = false;
      vm.failure = false;
      cfpLoadingBar.start();
      password = vm.password;
      var formData = {
        password:password
      }
      Authentication.reset(formData,token)
        .then(function(response){
            $log.log(response.data);
            if(response.data.code == 0){
              vm.errormessage = response.data.msg;
              vm.failure = true;
              cfpLoadingBar.complete();
            }else{
              vm.successmessage = response.data.msg;
              vm.success = true;
              cfpLoadingBar.complete();
            }
            
        })
        .catch(function(error){
            $log.log(error);
        })
    }
  }

})();
