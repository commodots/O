(function() {
  'use strict';

  angular
    .module('minotaur')
    .controller('SignupController', SignupController);

  /** @ngInject */
  function SignupController($scope,$log,$window,$timeout, $location,Authentication,vcRecaptchaService,cfpLoadingBar) {
    var vm = this;
    vm.model = {
        // key: '6LcwixYUAAAAAI1yVQT9tCg66Jg97wdPIu_Eu-uM'
        // key: '6LcyuhYUAAAAAGYjwoXQq2Oc7kdDRhXfDVQ_k6dW'
        key: '6LcgABcUAAAAAFgRvRQ_RMcl2izlTZgjdD7fg8Q0'
    };
    vm.redirectToLogin = function(){
      $location.path('/login');
    }
    vm.success = false;
    vm.failure = false;
    vm.submitForm = function(fullname,email,mobile,username,state,packageid,title,gender,account,bank,aname,password){
      vm.success = false;
      vm.failure = false;
      cfpLoadingBar.start();

      fullname = vm.name;
      email = vm.email;
      mobile = vm.mobile;
      username = vm.username;
      state = vm.state;
      packageid = vm.packageid;
      title = vm.title;
      gender = vm.gender;
	  account = vm.account;
      bank = vm.bank;
      aname = vm.aname;
      password = vm.password;

      function getCaptcha(){
        try{
          return vcRecaptchaService.getResponse();
        }
        catch (e){
          $log.log(e);
          return e;
        }
      }
      // $log.log(fullname);

      if(vcRecaptchaService.getResponse == ''){
        alert("Please resolve the captcha and submit")
      }else{
        var data = {
        title:title,
		fullname:fullname,
        email:email,
        mobile:mobile,
        username:email,
        state:state,
        packageid:packageid,
        account:account,
		aname:aname,
		bank:bank,
        gender:gender,
        password:password,
        'g-recaptcha-response':getCaptcha()
        }

        vm.$log = $log;
        // $log.log(vm.registerForm);
        $log.log(data);
        Authentication.register(data)
          .then(function(response){
            $log.log(response.data);
            if(response.data.code == 0){
              vm.failure = true;
              vm.errormessage = response.data.msg;
              cfpLoadingBar.complete(); 
              return; 
            }else{
              cfpLoadingBar.complete();
              vm.success = true;
              $timeout(vm.redirectToLogin,5000);
              return;
            }
            
            // return response;

          })
      }

      
      // $log.log(vm.recaptchaResp);
      
    }
    // vm.submitForm = function(isValid){
    //   alert("It works");
    // }
  }

})();
