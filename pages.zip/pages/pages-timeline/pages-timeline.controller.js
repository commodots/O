(function() {
  'use strict';

  angular
    .module('minotaur')
    .controller('PagesTimelineController', PagesTimelineController);

  /** @ngInject */
  function PagesTimelineController() {

  }


})();
