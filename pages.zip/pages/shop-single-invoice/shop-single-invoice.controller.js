(function() {
  'use strict';

  angular
    .module('minotaur')
    .controller('ShopSingleInvoiceController', ShopSingleInvoiceController);

  /** @ngInject */
  function ShopSingleInvoiceController() {

  }


})();
