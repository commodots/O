(function() {
  'use strict';

  angular
    .module('minotaur')
    .controller('ShopSingleOrderController', ShopSingleOrderController);

  /** @ngInject */
  function ShopSingleOrderController() {

  }


})();
