(function() {
  'use strict';

  angular
    .module('minotaur')
    .controller('UiButtonsController', UiButtonsController);

  /** @ngInject */
  function UiButtonsController() {

  }

})();
