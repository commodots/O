(function() {
  'use strict';

  angular
    .module('minotaur')
    .controller('UiGridController', UiGridController);

  /** @ngInject */
  function UiGridController() {

  }

})();
