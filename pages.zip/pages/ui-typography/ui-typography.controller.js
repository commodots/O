(function() {
  'use strict';

  angular
    .module('minotaur')
    .controller('UiTypographyController', UiTypographyController);

  /** @ngInject */
  function UiTypographyController() {

  }
})();
